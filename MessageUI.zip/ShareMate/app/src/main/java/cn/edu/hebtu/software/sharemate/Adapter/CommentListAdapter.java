package cn.edu.hebtu.software.sharemate.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import cn.edu.hebtu.software.sharemate.Bean.CommentBean;
import cn.edu.hebtu.software.sharemate.R;
import cn.edu.hebtu.software.sharemate.RoundImgView;

public class CommentListAdapter extends BaseAdapter {

    private Context context;
    private List<CommentBean> comments = new ArrayList<>();
    private int item_layout;

    public CommentListAdapter(Context context, List<CommentBean> comments, int item_layout) {
        this.context = context;
        this.comments = comments;
        this.item_layout = item_layout;
    }

    @Override
    public int getCount() {
        return comments.size();
    }

    @Override
    public Object getItem(int position) {
        return comments.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView==null){
            convertView = LayoutInflater.from(context).inflate(item_layout,null);
        }

        RoundImgView portraitView = convertView.findViewById(R.id.iv_portrait);
        portraitView.setImageResource(comments.get(position).getUser().getUserPhoto());
        TextView nameView = convertView.findViewById(R.id.tv_name);
        nameView.setText(comments.get(position).getUser().getUserName());
        Date date = comments.get(position).getDate();
        String time = new SimpleDateFormat("yyyy-MM-dd").format(date);
        TextView timeView = convertView.findViewById(R.id.tv_date);
        timeView.setText(time);
        TextView commentView = convertView.findViewById(R.id.tv_comment);
        commentView.setText(comments.get(position).getComment());
        ImageView noteView = convertView.findViewById(R.id.iv_note);
        noteView.setImageResource(comments.get(position).getNotePhoto());

        return convertView;
    }
}
