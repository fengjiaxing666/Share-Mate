package cn.edu.hebtu.software.sharemate.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import cn.edu.hebtu.software.sharemate.Adapter.MessageListAdapter;
import cn.edu.hebtu.software.sharemate.Bean.TitleBean;
import cn.edu.hebtu.software.sharemate.Activity.CommentActivity;
import cn.edu.hebtu.software.sharemate.Activity.FollowedActivity;
import cn.edu.hebtu.software.sharemate.Activity.LetterActivity;
import cn.edu.hebtu.software.sharemate.Activity.LikeActivity;
import cn.edu.hebtu.software.sharemate.R;

public class MessageFragment extends Fragment {

    private List<TitleBean> titles = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_message,container,false);
        titles.add(new TitleBean(R.drawable.like,"收到的赞"));
        titles.add(new TitleBean(R.drawable.comment,"收到的评论"));
        titles.add(new TitleBean(R.drawable.followed,"新增关注"));
        titles.add(new TitleBean(R.drawable.message,"收到的私信"));

        MessageListAdapter listAdapter = new MessageListAdapter(getActivity(),R.layout.message_list_item_layout,titles);
        ListView listView = view.findViewById(R.id.lv_message);
        listView.setAdapter(listAdapter);

        //为列表的每一项绑定点击监听器
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 0:
                        Intent likeIntent = new Intent(getActivity(), LikeActivity.class);
                        startActivity(likeIntent);
                        break;
                    case 1:
                        Intent commentIntent = new Intent(getActivity(), CommentActivity.class);
                        startActivity(commentIntent);
                        break;
                    case 2:
                        Intent followedIntent = new Intent(getActivity(), FollowedActivity.class);
                        startActivity(followedIntent);
                        break;
                    case 3:
                        Intent letterIntent = new Intent(getActivity(), LetterActivity.class);
                        startActivity(letterIntent);
                        break;
                }
            }
        });
        return view;
    }
}
