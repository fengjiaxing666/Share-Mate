package cn.edu.hebtu.software.sharemate.Bean;

import java.util.Date;

public class LikeBean {

   private  UserBean user;
    private String type;
    private Date date;
    private String comment;
    private int noteId;

    public LikeBean(UserBean user, String type, Date date, String comment, int noteId) {
        this.user = user;
        this.type = type;
        this.date = date;
        this.comment = comment;
        this.noteId = noteId;
    }

    public UserBean getUser() {
        return user;
    }

    public void setUser(UserBean user) {
        this.user = user;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getNoteId() {
        return noteId;
    }

    public void setNoteId(int noteId) {
        this.noteId = noteId;
    }
}
