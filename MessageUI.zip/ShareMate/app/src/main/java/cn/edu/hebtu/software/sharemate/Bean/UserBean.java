package cn.edu.hebtu.software.sharemate.Bean;

import java.io.Serializable;

public class UserBean implements Serializable {

    private String userName;
    private int userPhoto;

    public UserBean(String userName, int userPhoto) {
        this.userName = userName;
        this.userPhoto = userPhoto;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getUserPhoto() {
        return userPhoto;
    }

    public void setUserPhoto(int userPhoto) {
        this.userPhoto = userPhoto;
    }
}
