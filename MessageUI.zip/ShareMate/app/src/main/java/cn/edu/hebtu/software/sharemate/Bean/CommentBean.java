package cn.edu.hebtu.software.sharemate.Bean;

import java.util.Date;

public class CommentBean {

    private UserBean user;
    private Date date;
    private String comment;
    private int notePhoto;

    public CommentBean(UserBean user, Date date, String comment, int notePhoto) {
        this.user = user;
        this.date = date;
        this.comment = comment;
        this.notePhoto = notePhoto;
    }

    public UserBean getUser() {
        return user;
    }

    public void setUser(UserBean user) {
        this.user = user;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getNotePhoto() {
        return notePhoto;
    }

    public void setNotePhoto(int notePhoto) {
        this.notePhoto = notePhoto;
    }
}
