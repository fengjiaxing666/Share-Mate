package net.onest.sharemate.Tools;

/**
 * Created by admin on 2016/7/22.
 */

/**
 *
 * 类简要描述
 *
 * <p>
 * 类详细描述
 * </p>
 *
 * @author duanbokan
 *
 */

public class CountrySortToken
{
    // 简拼
    public String simpleSpell = "";

    // 全拼
    public String wholeSpell = "";

    // 中文全名
    public String chName = "";
}
