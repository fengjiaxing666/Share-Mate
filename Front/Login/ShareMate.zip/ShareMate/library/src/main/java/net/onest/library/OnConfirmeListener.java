package net.onest.library;

public interface OnConfirmeListener {
    void result(String s);
}
