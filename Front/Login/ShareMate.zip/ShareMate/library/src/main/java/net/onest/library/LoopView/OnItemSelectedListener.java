package net.onest.library.LoopView;

public interface OnItemSelectedListener {
    void onItemSelected(LoopView view);
}
