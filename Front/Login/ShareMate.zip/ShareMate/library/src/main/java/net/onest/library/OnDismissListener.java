package net.onest.library;

public interface OnDismissListener {
    public void onDismiss(Object o);
}
