package net.onest.library;

public interface OnItemClickListener {
    public void onItemClick(Object o, int position);
}
